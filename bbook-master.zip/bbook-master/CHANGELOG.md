## 0.1.5, 2018-08-31
- Filter for results (command 'f')

## 0.1.4, 2018-08-30
- Accidentially published private data in 0.1.3

## 0.1.3, 2018-08-30
- Search for results (command '/', repeat 'n')

## 0.1.2, 2018-07-23
- Add all fields from abook

## 0.1.1, 2018-07-23
- Rename from 'nbook'
- Default database file ~/bbook.db

## 0.1.0, 2018-07-23
- First public release
